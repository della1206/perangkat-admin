<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PerangkatDesaController;
use App\Http\Controllers\AuthController;

// =====================================
// DEFAULT DASHBOARD
// =====================================
Route::get('/', [PerangkatDesaController::class, 'index'])->name('perangkat-desa.index');

// Alternatif akses dashboard
Route::get('/admin/perangkat-desa', [PerangkatDesaController::class, 'index'])->name('perangkat-desa.admin');

// =====================================
// AUTH ROUTES
// =====================================
Route::get('/auth/login', [AuthController::class, 'index'])->name('auth.login');
Route::post('/auth/login', [AuthController::class, 'login'])->name('auth.login.post');
Route::get('/auth/success', [AuthController::class, 'success'])->name('auth.success');

Route::get('/auth/register', [AuthController::class, 'registerForm'])->name('auth.register.form');
Route::post('/auth/register', [AuthController::class, 'register'])->name('auth.register');
