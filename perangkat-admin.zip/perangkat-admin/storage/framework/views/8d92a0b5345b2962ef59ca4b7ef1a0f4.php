<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Perangkat Desa</title>

    <style>
        /* Background dengan gambar */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: url('/images/dashboard-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }

        /* Overlay agar teks lebih mudah dibaca */
        .overlay {
            background: rgba(0, 0, 0, 0.6);
            min-height: 100vh;
            padding: 40px;
        }

        h1 {
            text-align: center;
            margin-bottom: 40px;
            font-size: 36px;
            color: #3E97FF;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.4);
        }

        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
            background: rgba(255, 255, 255, 0.85);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.4);
        }

        th, td {
            padding: 15px;
            text-align: center;
            color: #333;
        }

        th {
            background-color: #3E97FF;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: rgba(240, 240, 240, 0.9);
        }

        img {
            width: 60px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        }

        .logout {
            text-align: center;
            margin-top: 30px;
        }

        .logout a {
            background-color: #3E97FF;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 10px;
            font-weight: bold;
            transition: 0.3s;
        }

        .logout a:hover {
            background-color: #0059d6;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <h1>📋 Dashboard Perangkat Desa</h1>

        <table>
            <tr>
                <th>ID</th>
                <th>Jabatan</th>
                <th>NIP</th>
                <th>Kontak</th>
                <th>Periode Mulai</th>
                <th>Periode Selesai</th>
                <th>Foto</th>
            </tr>

            <?php $__currentLoopData = $perangkat_desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item['perangkat_id']); ?></td>
                <td><?php echo e($item['jabatan']); ?></td>
                <td><?php echo e($item['nip']); ?></td>
                <td><?php echo e($item['kontak']); ?></td>
                <td><?php echo e($item['periode_mulai']); ?></td>
                <td><?php echo e($item['periode_selesai']); ?></td>
               <td><img src="<?php echo e(asset('assets/images/' . $item['foto'])); ?>" alt="<?php echo e($item['jabatan']); ?>" width="60" height="60" style="border-radius: 10px;"></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <div class="logout">
            <a href="<?php echo e(route('auth.login')); ?>">🔙 Logout</a>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\Della\laragon-6.0-minimal\www\perangkat-admin\resources\views/admin/perangkat_desa.blade.php ENDPATH**/ ?>