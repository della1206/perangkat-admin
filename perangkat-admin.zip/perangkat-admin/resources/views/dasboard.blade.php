@extends('layouts.app')

@section('content')
<div class="container mt-5 text-center">
    <h2>Selamat Datang Admin!</h2>
    <p>Anda berhasil login ke Dashboard.</p>
</div>
@endsection
